
# Instruções para o agente de IA

## Objetivo
Desenvolver um gerenciador financeiro pessoal
com interface moderna e funcionalidades completas.

## Tecnologias
- Frontend: React e TypeScript
- Backend: Node.js com Express e TypeScript
- Banco de dados: SQLite
- Interface em português brasileiro

## Regras de desenvolvimento
- Não inserir comentários desnecessários no código.
- Utilizar nomes claros para variáveis e funções.
- Arquivos TypeScript devem ter no máximo 100 linhas.
- Funções devem ter no máximo 30 linhas.
- Evitar mais de três níveis de condicionais.
- Utilizar no máximo três parâmetros por função.
- Extrair valores mágicos para constantes nomeadas.
- Organizar o código em arquivos menores.
- Validar todas as entradas do usuário.
- Não remover funcionalidades sem autorização.

## Regras financeiras
- Receitas aumentam o saldo.
- Despesas diminuem o saldo.
- O saldo mensal é receitas menos despesas do mês.
- Armazenar valores monetários em centavos inteiros.
- Permitir cadastrar, editar e excluir lançamentos.
- Persistir os dados no banco SQLite.

## Qualidade
- Implementar testes das regras financeiras.
- Verificar erros antes de finalizar.
- Manter a interface responsiva.
- Explicar como executar o projeto.
