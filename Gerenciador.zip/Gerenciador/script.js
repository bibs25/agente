
let movimentacoes = JSON.parse(
    localStorage.getItem("movimentacoes")
) || [];

const formulario = document.getElementById("form-financeiro");
const lista = document.getElementById("lista-movimentacoes");

function salvarDados() {
    localStorage.setItem(
        "movimentacoes",
        JSON.stringify(movimentacoes)
    );
}

function formatarMoeda(valor) {
    return valor.toLocaleString("pt-BR", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function atualizarTela() {
    let receitas = 0;
    let despesas = 0;

    lista.innerHTML = "";

    movimentacoes.forEach((movimentacao) => {
        if (movimentacao.tipo === "receita") {
            receitas += movimentacao.valor;
        } else {
            despesas += movimentacao.valor;
        }

        const item = document.createElement("li");

        const texto = document.createElement("span");
        texto.textContent =
            `${movimentacao.descricao} - R$ ${formatarMoeda(movimentacao.valor)} (${movimentacao.tipo})`;

        const botao = document.createElement("button");
        botao.textContent = "Excluir";
        botao.addEventListener("click", () => {
            excluirMovimentacao(movimentacao.id);
        });

        item.append(texto, " ", botao);
        lista.appendChild(item);
    });

    const saldo = receitas - despesas;

    document.getElementById("receitas").textContent =
        formatarMoeda(receitas);

    document.getElementById("despesas").textContent =
        formatarMoeda(despesas);

    document.getElementById("saldo").textContent =
        formatarMoeda(saldo);
}

formulario.addEventListener("submit", function(evento) {
    evento.preventDefault();

    const descricao = document.getElementById("descricao").value.trim();
    const valor = Number(document.getElementById("valor").value);
    const tipo = document.getElementById("tipo").value;

    if (!descricao || !Number.isFinite(valor) || valor <= 0) {
        alert("Preencha os dados corretamente.");
        return;
    }

    const movimentacao = {
        id: crypto.randomUUID(),
        descricao: descricao,
        valor: Math.round(valor * 100) / 100,
        tipo: tipo
    };

    movimentacoes.push(movimentacao);

    salvarDados();
    atualizarTela();
    formulario.reset();
});

function excluirMovimentacao(id) {
    movimentacoes = movimentacoes.filter(
        movimentacao => movimentacao.id !== id
    );

    salvarDados();
    atualizarTela();
}

atualizarTela();
